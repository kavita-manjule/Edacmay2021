package oopassignment1;

import java.util.Scanner;

/*07.	Write a program to calculate sum of 5 subject�s marks &
find percentage. Take the obtained marks from user
using Scanner class. Output should be in this format 
[ percentage marks = 99 % ]. 
Use concatenation operator here.*/
public class Ex7 {

	public static void main(String[] args) {
		
		int a ,sum=0 ,per;
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Enter marks of 5 subjects ");
		 for (int i = 0; i < 5; i++) {
			 
			a=sc.nextInt();
			sum = sum +a;
		}
		 
		 per = sum/5;
		 System.out.println("[ percentage marks = "+per+" % ]");

	}

}
