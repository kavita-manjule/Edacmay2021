package oopassignment1;

/*04.	Write a program that initializes 2 byte type of variables.
Add the values of these variables and store in a byte type of variable. 
[Note: primitive down casting is required in this program ] .
*/
public class Ex4 {

	public static void main(String[] args) {
		
		byte a,b,c;
		a=10;
		b=20;
		c= (byte) (a+b);
		System.out.println(c);
		
	}
}
