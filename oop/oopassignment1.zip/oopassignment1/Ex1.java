

package oopassignment1;

/*01.	Write a program to print Hello World. 
Compile and run it using command prompt.*/
public class Ex1 {

	public static void main(String[] args) {
		
		
		System.out.println("Hello World");

	}

}
