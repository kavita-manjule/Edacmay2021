package oopassignment1;

import java.util.Scanner;

/*09.	Write a program to read the days (eg. 670 days) as integer value 
using Scanner class. Now convert the entered days into complete years,
months and days and print them.*/
public class Ex9 {

	public static void main(String[] args) {
		
		int days ;
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Enter the number of days ");
		 days= sc.nextInt();
		 int y ,m,d,mn;
		 y=days/365;
		 m=days%365;
		 mn=m/30;
		 d=m%12;
		 System.out.println("Years ="+y +" Months ="+ mn+" Days = "+d);
			 
		 

	}

}
