package oopassignment1;

import java.util.Scanner;

/*10.	Write a program to convert temperature from Fahrenheit to Celsius. 
Take Fahrenheit as input using Scanner class. [ formula : C= 5*(f-32)/9 ]*/
public class Ex10 {

	public static void main(String[] args) {
         
		double F,C;
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Enter the temperature in Fahrenheit  ");
		 F= sc.nextDouble();
		 C = (5*(F-32))/9;
		 System.out.println("Temperature in Celsius "+ C);
		

	}

}
