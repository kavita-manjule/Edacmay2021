package oopassignment1;

import java.util.Scanner;

/*15.	Accept person�s gender (character m for male and f for female), 
age (integer), as input and 
then check whether person is eligible for marriage or not.*/
public class Ex15 {

	public static void main(String[] args) {

		char g;
		int age = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the gender male =m ,female =f ");
		g = sc.next().charAt(0);
		if (g == 'm' || g == 'f') {
			System.out.println("Enter the age ");
			age = sc.nextInt();
		}

		if (g == 'm') {
			if (age >= 21) {
				System.out.println("person is eligible for marriage");
			} else {
				System.out.println("person is not eligible for marriage");

			}

		} else if (g == 'f') {
			if (age >= 18) {
				System.out.println("person is eligible for marriage");
			} else {
				System.out.println("person is not eligible for marriage");

			}
		} else {

			System.out.println("please enter valid gender");

		}

	}

}
