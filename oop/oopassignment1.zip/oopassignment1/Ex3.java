package oopassignment1;

/*03.	Find the result of following expressions. You need to determine the primitive 
 * data type of the variable by looking carefully the given expression and 
 * initialize variables by any random value.
A. y = x2 + 3x - 7 (print value of y) 
B. y = x++ + ++x (print value of x and y) 
C. z = x++ - --y - --x  +  x++ (print value of x ,y and z)
D. z = x && y || !(x || y)  (print value of z) [ x, y, z are boolean variables ]*/

public class Ex3 {

	public static void main(String[] args) {
		
		int x ,y , z;
		x=2;
		y=(x*x) +(3*x) -7;
		System.out.println(y);
		
		x=10;
		y=x++ + ++x;
		System.out.println(x+" "+y);
		
		x=2;
		y=2;
		z = x++ - --y - --x  +  x++;
		System.out.println(x+" "+y+" "+z);
		
		boolean p =true , q=false, r;
		r= p && q || !(p || q);
		System.out.println(r);
		
	}

}
