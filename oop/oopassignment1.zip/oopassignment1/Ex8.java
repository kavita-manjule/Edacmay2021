package oopassignment1;

import java.util.Scanner;

/*08.	Write a program to find the simple interest.
Take the principle amount, rate of interest and
time from user using Scanner class.*/
public class Ex8 {

	public static void main(String[] args) {
		
		double p ,r ,t ,si;
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Enter the principle amount ");
		 p= sc.nextDouble();
		 System.out.println("Enter the rate ");
		 r= sc.nextDouble();
		 System.out.println("Enter the time ");
		 t= sc.nextDouble();
		 si =(p*r*t)/100;
		 System.out.println("Simple interest "+si);
		 
		

	}

}
