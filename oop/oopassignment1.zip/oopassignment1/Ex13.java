package oopassignment1;

import java.util.Scanner;

/*13.	Program to find greatest in 3 numbers.
[ once using if else statement and
   then using ternary operator ( logical operator) ]  */
public class Ex13 {

	public static void main(String[] args) {
		
		
		int a, b, c;
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Enter the first value");
		 a= sc.nextInt();
		 System.out.println("Enter the second value");
		 b= sc.nextInt();
		 System.out.println("Enter the third value");
		 c= sc.nextInt();
		 System.out.print("greatest of three numbers: ");
		 if(a>b&&a>c)
		 {
			 System.out.println(a);
		 }
		 else if(b>a&&b>c)
		 {
			 System.out.println(b);
			 
		 }
		 else
		 {
			 System.out.println(c);
		 }
		System.out.println("method 2"); 
		int max=a>b?a>c?a:c:b>c?b:c;
		System.out.println("greatest of three numbers: "+max);

	}

}
