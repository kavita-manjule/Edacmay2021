package oopassignment1;

import java.util.Scanner;

/*06.	Write a program that takes radius of a circle as input.
Read the entered radius using Scanner class. 
Then calculate and print the area and circumference of the circle.*/
public class Ex6 {

	public static void main(String[] args) {

          double area ,radius,perimeter;
          
          Scanner sc = new Scanner(System.in);
          
          System.out.println("Enter the radius");
          radius = sc.nextDouble();
          area = Math.PI*radius*radius;
          perimeter=2*Math.PI*radius;
          System.out.println("Area of circle "+area);
          System.out.println("Perimeter of circle "+perimeter);

	}

}
