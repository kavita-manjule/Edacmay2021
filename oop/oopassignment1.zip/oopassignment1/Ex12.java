package oopassignment1;

import java.util.Scanner;

/*12.	In a company an employee is paid as under: If his basic salary is less than 
Rs. 10000, then HRA = 10% of basic salary and DA = 90% of basic salary. 
If his salary is either equal to or above Rs. 10000, then HRA = Rs. 2000 and 
DA = 98% of basic salary. If the employee's salary is input by the user
write a program to find his gross salary. [ formula : GS= Basic + DA + HRA ]*/
public class Ex12 {

	public static void main(String[] args) {

		double Basic, DA = 0, HRA = 0, GS;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Salary ");
		Basic = sc.nextDouble();
		if (Basic < 10000) {
			HRA = Basic * 0.1;
			DA = Basic * 0.90;
		} else if (Basic >= 10000) {
			HRA = 2000;
			DA = Basic * 0.98;
		}

		GS = Basic + DA + HRA;
		System.out.println("Gross Salary = "+GS);

	}

}
