package oopassignment1;

import java.util.Scanner;

/*14.	Program to check that entered year is a leap year or not.*/
public class Ex14 {

	public static void main(String[] args) {
		
		int y;
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Enter the first value");
		 y= sc.nextInt();
		 if(y%4==0)
		 {
			if(y%100==0)
			{
				if(y%400==0)
				{
					System.out.println("century leap year");
				}
				else
				{
					System.out.println("Not century leap year");
					
				}
			}
			else
			{
				System.out.println("leap year");
				
			}
		 }
		 else
		 {
			 System.out.println("not leap year");
		 }

	}

}
