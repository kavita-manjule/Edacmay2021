package assignment1;

import java.util.Scanner;

/*20. Write a Java program to convert a decimal number to hexadecimal number. 
Input Data:
Input a decimal number: 15
Expected Output
Hexadecimal number is : F */
public class Ex20 {

	public static void main(String[] args) {

		int decimal;
		Scanner sc = new Scanner(System.in);
		System.out.println("Input a Decimal number : ");
		decimal = sc.nextInt();
		int rem;
		String hex = "";
		char hexchars[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
		while (decimal > 0) {
			rem = decimal % 16;
			hex = hexchars[rem] + hex;
			decimal = decimal / 16;
		}
		System.out.println("Hexadecimal number is : "+hex);
		
		sc.close();

	}

}
