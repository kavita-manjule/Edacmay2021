package assignment1;

/*16. Write a Java program to print a face. 
*/

public class Ex16 {

	public static void main(String[] args) {

		int i, j;
		for (i = 0; i < 6; i++) {
			for (j = 0; j <= 8; j++) {

				if ((i == 0)) {
					if ((j == 1 || j == 7))
						System.out.print("+");
					else if (j > 1 && j < 7)
						System.out.print("\"");
					else
						System.out.print(" ");
				} else if (i == 1) {
					if (j == 0) {
						System.out.print("[");
					} else if (j == 1 || j == 7) {
						System.out.print("|");

					} else if (j == 3 || j == 5) {
						System.out.print("o");
					} else if (j == 8) {
						System.out.print("]");
					} else {
						System.out.print(" ");
					}
				} else if (i == 2) {
					if (j == 4) {
						System.out.print("^");
					} else if (j == 1 || j == 7) {
						System.out.print("|");

					} else {
						System.out.print(" ");
					}
				} else if (i == 3) {

					if (j == 3 || j == 5) {
						System.out.print("-");
					} else if (j == 1 || j == 7) {
						System.out.print("|");

					} else {
						System.out.print(" ");
					}

				} else if (i == 4) {

					if (j == 4) {
						System.out.print("-");
					} else if (j == 1 || j == 7) {
						System.out.print("|");

					} else {
						System.out.print(" ");
					}

				} 

				else if (i == 5) {
					if ((j == 1 || j == 7))
						System.out.print("+");
					else if (j > 1 && j < 7)
						System.out.print("-");
					else
						System.out.print(" ");
				}

			}

			System.out.println();
		}

	}

}
