package assignment1;

import java.util.Scanner;

/*15. Write a Java program to swap two variables. 
*/
public class Ex15 {

	public static void main(String[] args) {
		
		int a,b,c;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter value of a");
		a=sc.nextInt();
		System.out.println("Enter value of b");
		b=sc.nextInt();
		System.out.println("Before Swapping ");
		System.out.println("Value of a = "+a);
		System.out.println("value of b = "+b);
		
		//swapping 
		c=a;
		a=b;
		b=c;
		
		System.out.println("After Swapping ");
		System.out.println("Value of a = "+a);
		System.out.println("value of b = "+b);
		
		sc.close();

	}

}
