package assignment1;

import java.util.Scanner;

/*25. Write a Java program to convert a octal number to a decimal number. 
Input Data:
Input any octal number: 10
Expected Output
Equivalent decimal number: 8*/

public class Ex25 {

	public static void main(String[] args) {
		
		int octal;
		Scanner sc = new Scanner(System.in);
		System.out.println("Input a Octal number : ");
		octal = sc.nextInt();
		int decimal = 0;    
	    int n = 0;    
	    
	    while(true){    
	      if(octal == 0){    
	        break;    
	      } else {    
	          int temp = octal%10;    
	          decimal += temp*Math.pow(8, n);    
	          octal = octal/10;    
	          n++;    
	       }    
	    }  
	    
	    System.out.println("Equivalent decimal number : "+decimal);
	    
	    sc.close();

	}

}
