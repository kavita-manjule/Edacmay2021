package assignment1;

import java.util.Scanner;

/*12. Write a Java program that takes three numbers as input to calculate and print the 
average of the numbers.*/
public class Ex12 {

	public static void main(String[] args) {
		 
		double a, b, c,Average;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter three numbers");
		a=sc.nextDouble();
		b=sc.nextDouble();
		c=sc.nextDouble();
		Average =(a+b+c)/3;
		System.out.println("Average ="+ Average);
		sc.close();
		
		
		

	}

}
