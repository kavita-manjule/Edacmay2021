package assignment1;

import java.util.Scanner;

/*9. Write a Java program to convert a decimal number to binary number. 
Input Data:
Input a Decimal Number : 5
Expected OutputBinary number is: 101 */
public class Ex19 {

	public static void main(String[] args) {
		
		int decimal;
		Scanner sc = new Scanner(System.in);
		System.out.println("Input a Decimal number : ");
		decimal=sc.nextInt();
		int binary[] = new int[40];  
		
	     int index = 0;    
	     while(decimal > 0){ 
	    	 
	       binary[index++] = decimal%2;    
	       decimal = decimal/2;  
	       
	     }   
	     
	     System.out.print("Binary Number is : ");
	     for(int i = index-1;i >= 0;i--){    
	       System.out.print(binary[i]); 
	     }
	     
	     
	     sc.close();
	}

}
