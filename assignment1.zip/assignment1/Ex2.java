package assignment1;


/*Write a Java program to print the sum of two numbers. 
Test Data: 74 + 36*/

public class Ex2 {

	public static void main(String[] args) {
		
		System.out.println(74+36);

	}

}
