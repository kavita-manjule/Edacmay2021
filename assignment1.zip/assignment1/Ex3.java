package assignment1;


/*Write a Java program to divide two numbers and print on the screen. 
Test Data : 50/3
Expected Output : 16*/
public class Ex3 {

	public static void main(String[] args) {
		System.out.println(50/3);

	}

}
