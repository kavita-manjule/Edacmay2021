package assignment1;

import java.util.Scanner;

/*23. Write a Java program to convert a binary number to hexadecimal number. 
Input Data:
Input a Binary Number: 1101
Expected Output
HexaDecimal value: D*/

public class Ex23 {

	public static void main(String[] args) {
		
		
		int binary;
		Scanner sc = new Scanner(System.in);
		System.out.println("Input a Binary number : ");
		binary = sc.nextInt();
		int decimal = 0;  
	    int n = 0;  
	    while(true){  
	      if(binary == 0){  
	        break;  
	      } else {  
	          int temp = binary%10;  
	          decimal += temp*Math.pow(2, n);  
	          binary = binary/10;  
	          n++;  
	       }  
	    }  

	   // System.out.println("Decimal Number :"+decimal);
	    int rem;
		String hex = "";
		char hexchars[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
		while (decimal > 0) {
			rem = decimal % 16;
			hex = hexchars[rem] + hex;
			decimal = decimal / 16;
		}
		System.out.println("Hexadecimal value : "+hex);
	    
	    sc.close();

	}

}
