package assignment1;

import java.util.Scanner;

/*18. Write a Java program to multiply two binary numbers. 
Input Data:
Input the first binary number: 10
Input the second binary number: 11
Expected Output
Product of two binary numbers: 110*/
public class Ex18 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int bin1, bin2;
		int m = 0, num, t = 1;

		System.out.println("Input first binary number");
		bin1 = sc.nextInt();
		System.out.println("Input second binary number");
		bin2 = sc.nextInt();

		while (bin2 != 0) {

			num = bin2 % 10;
			if (num == 1) {
				bin1 = bin1 * t;
				m = binpro(bin1, m);
			} else {
				bin1 = bin1 * t;
			}

			bin2 = bin2 / 10;
			t = 10;

		}

		System.out.println("Product of two binary numbers :" + m);

		sc.close();

	}

	static int binpro(int b1, int b2) {
		int z = 0, cr = 0;
		int total[] = new int[50];
		int output = 0;
		while (b1 != 0 || b2 != 0) {
			total[z++] = (b1 % 10 + b2 % 10 + cr) % 2;

			cr = (b1 % 10 + b2 % 10 + cr) / 2;
			b1 = b1 / 10;
			b2 = b2 / 10;

		}

		if (cr != 0) {
			total[z++] = cr;
		}
		--z;
		while (z >= 0) {
			output = output * 10 + total[z--];
		}

		return output;

	}

}
