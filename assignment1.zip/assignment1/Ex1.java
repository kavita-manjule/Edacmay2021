package assignment1;


/*Write a Java program to print 'Hello' on screen and then print your name on a 
separate line. 
Expected Output : 
Hello
Alexandra Abramov*/
public class Ex1 {

	public static void main(String[] args) {
   
		System.out.println("Hello");
		System.out.println("Kavita Manjule");
		

	}

}
