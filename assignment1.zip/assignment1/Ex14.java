package assignment1;

public class Ex14 {

	public static void main(String[] args) {
		int i ,j;
		
		for(i=1;i<=15;i++)
		{
			for(j=1;j<=35;j++)
			{
				if(j<12&&i<=9)
				{
				if(i%2==0)
				{
					if(j%2==0)
				    System.out.print("*");
					else
					System.out.print(" ");
				}
				else {
					   
					    if(j%2==0)
					    System.out.print(" ");
						else
						System.out.print("*");		    
				}
				}
				else if(j==12&&i<=9)
				{
					System.out.print(" ");
				}
				else
				System.out.print("=");
			}
			System.out.println();
		}

	}

}
