package assignment1;

import java.util.Scanner;

/*21. Write a Java program to convert a decimal number to octal number. 
Input Data:
Input a Decimal Number: 15
Expected Output
Octal number is: 17*/
public class Ex21 {

	public static void main(String[] args) {

		int decimal;
		Scanner sc = new Scanner(System.in);
		System.out.println("Input a Decimal number : ");
		decimal = sc.nextInt();
		int rem; 
		String octal = ""; 
		
		char octalchars[] = { '0', '1', '2', '3', '4', '5', '6', '7' };
		while (decimal > 0) {
			rem = decimal % 8;
			octal = octalchars[rem] + octal;
			decimal = decimal / 8;
		}
		System.out.println("Octal number is : "+octal);
		
		sc.close();

	}

}
