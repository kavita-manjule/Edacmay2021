package assignment1;

public class Ex8 {

	public static void main(String[] args) {

		int i, j;

		for (i = 0; i <= 3; i++)// here is mistake change 1 as 11
		{

			// j alphabate

			for (j = 0; j <= 3; j++) {

				if (i >= 0 && i <= 2 && j == 3 || i == 2 && j == 0 || i == 3 && j < 3 && j > 0) {
					System.out.print("j");
				} else {
					System.out.print(" ");
				}
			}

			// A alphabate

			for (j = 0; j <= 6; j++) {

				if (j > 0 && j < 6 && i == 2 || (j < 1 || j > 5) && i == 3 || i == 1 && (j == 2 || j == 4)
						|| i == 0 && j == 3) {
					System.out.print("a");
				} else {
					System.out.print(" ");
				}

			}

          // v alphabate

			for (j = 0; j <= 6; j++) {

				if (i + j == 6 || i == j)
					System.out.print("V");
				else
					System.out.print(" ");
			}

			// A alphabate

			for (j = 0; j <= 6; j++) {

				if (j > 0 && j < 6 && i == 2 || (j < 1 || j > 5) && i == 3 || i == 1 && (j == 2 || j == 4)
						|| i == 0 && j == 3) {
					System.out.print("a");
				} else {
					System.out.print(" ");
				}

			}

			System.out.println();
		}

	}

}
