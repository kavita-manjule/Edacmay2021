package assignment1;

import java.util.Scanner;

/*22. Write a Java program to convert a binary number to decimal number. 
Input Data:
Input a binary number: 100
Expected Output
Decimal Number: 4 */
public class Ex22 {

	public static void main(String[] args) {
		
		
		int binary;
		Scanner sc = new Scanner(System.in);
		System.out.println("Input a Binary number : ");
		binary = sc.nextInt();
		int decimal = 0;  
	    int n = 0;  
	    while(true){  
	      if(binary == 0){  
	        break;  
	      } else {  
	          int temp = binary%10;  
	          decimal += temp*Math.pow(2, n);  
	          binary = binary/10;  
	          n++;  
	       }  
	    }  

	    System.out.println("Decimal Number :"+decimal);
	    
	    sc.close();
	}

}
