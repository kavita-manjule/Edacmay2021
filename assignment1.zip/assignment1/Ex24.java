package assignment1;

import java.util.Scanner;

/*24. Write a Java program to convert a binary number to a Octal number. 
Input Data:
Input a Binary Number: 111
Expected Output
Octal number: 7*/
public class Ex24 {

	public static void main(String[] args) {
		
		
		int binary;
		Scanner sc = new Scanner(System.in);
		System.out.println("Input a Binary number : ");
		binary = sc.nextInt();
		int decimal = 0;  
	    int n = 0;  
	    while(true){  
	      if(binary == 0){  
	        break;  
	      } else {  
	          int temp = binary%10;  
	          decimal += temp*Math.pow(2, n);  
	          binary = binary/10;  
	          n++;  
	       }  
	    }  

	    //System.out.println("Decimal Number :"+decimal);
	    int rem; 
		String octal = ""; 
		
		char octalchars[] = { '0', '1', '2', '3', '4', '5', '6', '7' };
		
		while (decimal > 0) {
			rem = decimal % 8;
			octal = octalchars[rem] + octal;
			decimal = decimal / 8;
		}
		System.out.println("Octal number is : "+octal);
     
		sc.close();
	    

	}

}
