package assignment2;

public class P18 {

	public static void main(String[] args) {


		int i,j;
		char ch;
		for(i=5;i>=1;i--)
		{
			ch='A';
			for(j=1;j<=i;j++)
			{
				System.out.print(ch+" ");
				ch++;
			}
			
			System.out.println();
		}


	}

}
