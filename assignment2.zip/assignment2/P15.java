package assignment2;

public class P15 {

	public static void main(String[] args) {

         
		int i,j,k;
		for(i=5;i>=1;i--)
		{
			k=5;
			for(j=1;j<=i;j++)
			{
				System.out.print(k+" ");
				k--;
			}
			
			System.out.println();
		}

	}

}
