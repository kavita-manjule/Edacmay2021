package assignment2;

public class P9 {

	public static void main(String[] args) {


		int i,j,n;
		char ch;
//		Scanner sc = new Scanner(System.in);
//		System.out.println("Enter the number of rows :");
//		n=sc.nextInt();
		for(i=5;i>=1;i--)
		{
			ch='A';
			for(j=1;j<=i-1;j++)
			{
				System.out.print(" ");
			}
			for(j=i;j<=5;j++)
			{
				
				System.out.print(""+ch+" ");
				ch++;
			}
			
			
			System.out.println();
		}

	}

}
