package assignment2;

public class P10 {

	public static void main(String[] args) {
		
		
		char i,j;
		int k,n,l;
	
//		Scanner sc = new Scanner(System.in);
//		System.out.println("Enter the number of rows :");
//		n=sc.nextInt();
		
	    l=4;
		for(i='E';i>='A';i--)
		{
		
			for(k=1;k <=l;k++)
			{
				System.out.print(" ");
			}
			for(j=i;j<='E';j++)
			{
			
				System.out.print(""+j+" ");
				
			}
			l--;
			
			System.out.println();
		}

	}

}
