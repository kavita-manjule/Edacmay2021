package assignment2;

import java.util.Scanner;

public class P8 {

	public static void main(String[] args) {


		int i,j,n;
//		Scanner sc = new Scanner(System.in);
//		System.out.println("Enter the number of rows :");
//		n=sc.nextInt();
		for(i=5;i>=1;i--)
		{
			for(j=1;j<=i-1;j++)
			{
				System.out.print(" ");
			}
			for(j=i;j<=5;j++)
			{
				
				System.out.print(""+j+" ");
			}
			
			System.out.println();
		}
		


	}

}
